OVWijzig v2.0 - Source
======================

OVwijzig is geschreven in Delphi (XE):
http://www.embarcadero.com/products/delphi

Verder is er gebruik gemaakt van DISQLite3 voor de koppeling met een SQLite database bestand:
http://www.yunqa.de/delphi/doku.php/products/sqlite3/index (download Personal, rechtsbovenin het scherm).

