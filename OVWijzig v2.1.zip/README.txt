OVWijzig v2.0
==============

Dit programma kan bij een dump van een OV-chipkaart de gegevens van de laatste check-in aanpassen.
Hiermee kunt u dus thuis inchecken zonder dat er saldo van uw kaart wordt afgeschreven.

Nieuw in v2.0
--------------

Station namen worden nu geladen vanuit een database bestand. 
Voorlopig is dit alleen ingeschakeld voor NS treinen.
Je kunt schakelen tussen de station namen en -nummers met de checkbox aan de rechterkant.
Wanneer je in de listbox een station selecteerd, zullen de bijbehorende machineID's in een listbox geladen worden vanuit de database.
Vergeet in dat geval niet een van de machineID uit de listbox te selecteren (de laatst geselecteerde machineID wordt in de dump geschreven).
Als er geen listbox verschijnt, dan zijn er geen machineID's van dat station bekend.
Bij de machineID's kun je met de checkbox schakelen tussen de listbox en een tekstveld.
In het tekstveld zal altijd de laatst geselecteerde machineID staan weergegeven.
De waarde in het tekstveld zal in de dump geschreven worden.
Zodra je de dump opslaat, zal OVWijzig als extra controle een melding geven als de bedrijf-station-machineid combinatie NIET in de database voorkomt.
Van veel stations zijn nog geen machineID's bekend. 
Help daarom de OV-chipkaart.me community mee met verzamelen:
http://www.ov-chipkaart.me/forum/viewtopic.php?f=10&t=61 

Wat werkt?
--------------

- Alleen aanpassen van datum en tijd (werkt: getest door verschillende gebruikers)
- Aanpassen van station EN machine combinatie die voorkomt in de machineID database 
  (niet getest, maar zou in theorie moeten werken)

Rules of thumb
--------------

- Gebruik altijd een anonieme OV-chipkaart die je met muntgeld hebt gekocht.
- Een blokkering voorkom je als volgt:
  haal nooit een OV-chipkaart langs een check-in apparaat als de werkelijke kaartinhoud afwijkt met wat de TLS back-office zou verwachten.
- Inschakelen van 'Geavanceerde opties' is alleen bedoeld voor gevorderde gebruikers!
  De werking van OVwijzig wordt NIET gegarandeerd wanneer je 'Geavanceerde opties' inschakeld.

Benodigdheden
--------------

- Een kaartlezer (http://www.ov-chipkaart.me/forum/viewtopic.php?f=7&t=6)
- MFOC GUI (programma om de OV chipkaart uit te lezen) http://www.huuf.info/OV
- Een dump van een anonieme (!) OV-chipkaart die gemaakt is na een in-check

Handleiding
--------------

1. Men nemen een ov-kaart.
2. Men zet hier een bedrag van 20 euro op.
3. Men checkt in.
4. Men maakt met MFOC GUI een dump door middel van de computer.
5. Wil men de borg van 20 euro terug, dan dient men op het zelfde station weer uit te checken. 
   Dit vereist een laptop of men moet dicht bij het station wonen.
6. Men nemen OVWijzig en opent met dit stukje software de eerder gemaakte dump, men verandert de datum, tijd, station en/of machine.
7. Men slaat de dump op, en schrijft deze door middel van MFOC GUI naar zijn of haar chip-kaart.
8. Men nemen de trein, in geval van controle zal de conducteur zien dat je bent ingecheckt.

Met dank aan Hayo: http://www.ov-chipkaart.me/forum/viewtopic.php?f=8&t=47

Stap 1: Men nemen een ov-kaart
Koop altijd een anonieme kaart met muntgeld (het liefst uit het zicht van camera's).
Op deze manier is je kaart niet traceerbaar door TLS.

Stap 2: Men zet hier een bedrag van 20 euro op
Laad je OV-chipkaart legaal op met 20 euro, dus niet illegaal met OVsaldo. 
Je kaart zal anders geblokkeerd worden nadat je een check-in maakt (stap 3).
Aangezien de conducteurs elke dag een update krijgen van geblokkeerde kaarten, zal je in dat geval door de mand vallen bij controle.

Stap 3: Men checkt in
Check in bij de vervoerder waar je bij wilt reizen. 
In OVwijzig kun je standaard namelijk niet de vervoerder wijzigen.

Stap 4: Men maakt met MFOC GUI een dump door middel van de computer
Met MFOC GUI kun je de sleutels van je OV-chipkaart kraken en je OV-chipkaart lezen en beschrijven.
Kijk bij 'probleemoplosing' op http://www.huuf.info/OV als het programma niet werkt en zorg dat de drivers van je kaartlezer geinstaleerd zijn.
Bij een nieuwe kaart kost het achterhalen van de sleutels eenmalig 30-60 min.
Als de sleutels bekend zijn, kost het lezen en schrijven naar de kaart in het vervolg een aantal seconden.
Let er op dat 'Use Key A' en 'Use Key B' zijn aangevinkt als je een dump maakt!
Zorg er verder voor dat 'Dump to file' en 'OV card - Read everything' staan aangevinkt.
Klik op 'Read data (reader)' om de sleutels te kraken en een dump van je kaart te maken.
Standaard zal MFOC GUI het dump bestand (extensie *.dump) in dezelfde map neerzetten als mfocGUI.exe.

Stap 5: ... op het zelfde station weer uitchecken
Zorg dat je binnen een uur weer uitcheckt. 
Je hoeft dan namelijk geen instaptarief te betalen en daarmee behoudt je het saldo van 20 euro op je kaart.

Stap 6: Men nemen OVWijzig en ... men verandert de datum, tijd, station en/of machine 
Verschillende mensen hebben laten weten dat alleen het aanpassen van de datum en tijd gegarandeerd werkt.
In v2.0 van OVwijzig is het nu ook mogelijk om het station te wijzigen, maar dit maakt het noodzakelijk om ook de machine te wijzigen.
Stel dat je legaal incheckt op Den haag centraal en je veranderd het station naar Rotterdam centraal.
Als je de machine niet ook wijzigt, dan ben je dus ingechecked in Rotterdam centraal, maar bij een paaltje die in Den Haag centraal staat.
Het is niet bekend of PDA's van de conduceurs hierop controleert, maar 'better safe than sorry'.
Om die reden is de OV-chipkaart.me community begonnen met het verzamelen van machineID's van ieder (NS) station.
OVwijzig maakt gebruik van deze database, maar van veel stations zijn nog geen machineID's bekend.
Help daarom mee om machineID's te verzamelen: http://www.ov-chipkaart.me/forum/viewtopic.php?f=10&t=61.
Wanneer je een station selecteert in OVwijzig, dan zal er een listbox verschijnen als er machineID's bekend zijn van dat station.
Let er wel op dat je wel een machineID moet selecteren, anders wordt de oorspronkelijk (of laatste geselecteerde) machineID naar de dump geschreven.
Verschijnt er geen listbox, dan blijft de oorspronkelijk (of laatst geselecteerde) machineID staan.
Het weergeven en selecteren van stations is voorlopig alleen ingeschakeld voor check-in's van NS treinen.

7. ... en schrijft deze ... naar zijn of haar chip-kaart
Selecteer in MFOC GUI 'Non-Ov card'. 
Klik vervolgens op 'Write data (reader)' (vink 'write keys' NIET aan!!)
Selecteer de dump die zojuist is aangemaakt in OVwijzig.
De dump wordt nu op je OV-kaart geschreven.
Het is mogelijk om de dump naar een andere kaart te schrijven dan de oorspronkelijke kaart.
Dit kan handig zijn om de oorspronkelijke kaart, met 20 euro saldo, legaal te blijven gebruiken.

8. Men nemen de trein ...
Wanneer je nu de trein neemt, zal de conducteur de check-in zien zoals je die hebt ingesteld met OVwijzig.
De PDA's van de conducteurs lezen de OV-chipkaart alleen uit en sturen geen informatie over je kaart-inhoud terug naar de TLS back-office.
TLS kan daarom niet detecteren dat je met een gemanipuleerde kaart reist.
Volgens een frauderapport aan de tweede kamer, zal TLS in de toekomst wel bij controles de kaarten gaan 'loggen'.
Hierdoor zal OVWijzig op termijn niet meer werken, maar vooralsnog lijkt TLS niet veel haast te hebben met hun fraude preventie maatregelen.
Let er wel op dat je een gemanipuleerde kaart NIET langs check-in paaltje haalt (zie de 'rules of thumb').
TLS kan in dat geval zien dat je kaartinhoud niet klopt en zal de kaart blokkeren.
Je kunt ter controle je kaart wel uitlezen bij de gele NS-kaartautomaten, 
maar er zijn geruchten dat ook deze machines de kaartinhoud doorsturen naar de back-office van TLS.

Changelog
--------------

v2.1
- Koppeling met machineID database alleen ingeschakeld voor NS check-ins

v2.0
- Koppeling met machineID database zodat de station namen worden afgebeeld en machineID geselecteerd kunnen worden.
- Gebruiker krijgt een melding als de bedrijf-station-machine combinatie niet voorkomt in de machineID database.

v1.1
- Alleen datum en tijd zijn standaard aan te passen
- Gebruiker krijgt melding als er andere transacties zijn die later in de tijd liggen dan de gewijzigde check-in.
- Source gereleased

v1.0
- Eerste release