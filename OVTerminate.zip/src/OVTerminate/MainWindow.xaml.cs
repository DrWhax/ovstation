﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OVTerminate.Services;
using Microsoft.Win32;
using System.IO;

namespace OVTerminate
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();

            PendingActionsList.ItemsSource = App.Transactions;
        }

        /// <summary>
        /// Show credit form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CreditButton_Click(object sender, RoutedEventArgs e)
        {
            CreditUC.Visibility = Visibility.Visible;

            TransactionUC.Visibility = Visibility.Collapsed;
           
        }

        /// <summary>
        /// Checkin button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckinButton_Click(object sender, RoutedEventArgs e)
        {
            TransactionUC.Visibility = Visibility.Visible;

            CreditUC.Visibility = Visibility.Collapsed;

        }

        /// <summary>
        /// Load data from file (Copied from OV Saldo)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoadDumpButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Dumps (*.dump)|*.dump|Alle bestanden (*.*)|*.*";
            dialog.ShowDialog();

            if(!string.IsNullOrEmpty(dialog.FileName) && dialog.CheckFileExists)
            {
                FileStream stream = new FileStream(dialog.FileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                if (stream.Length != 0x1000L)
                {
                    MessageBox.Show("Ongeldige dump!");
                }
                else
                {
                    App.DumpData = new byte[0x1000];
                    stream.Read(App.DumpData, 0, 0x1000);
                    stream.Close();

                    this.SaveDumpButton.Visibility = System.Windows.Visibility.Visible;
                }
            }
        }

        /// <summary>
        /// Save the data to a file (Copied from OV Saldo)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveDumpButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog dialog = new SaveFileDialog();
                dialog.Filter = "Dumps (*.dump)|*.dump|Alle bestanden (*.*)|*.*";
                dialog.ShowDialog();

                if (!string.IsNullOrEmpty(dialog.FileName))
                {
                    //Write all data to the dump in memory
                    WriteActionService.WriteAllData();

                    if (File.Exists(dialog.FileName))
                    {
                        File.Delete(dialog.FileName);
                    }
                    FileStream stream = new FileStream(dialog.FileName, FileMode.Create, FileAccess.Write, FileShare.None);
                    stream.Write(App.DumpData, 0, 0x1000);
                    stream.Flush();
                    stream.Close();

                    MessageBox.Show("Fijne reis.");

                    App.DumpData = null;
                    SaveDumpButton.Visibility = System.Windows.Visibility.Hidden;


                }
            }
            catch
            {
                MessageBox.Show("Error writing data.");
            }
        }
    }
}
