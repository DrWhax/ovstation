﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OVTerminate.Services;
using OVTerminate.Transactions;
using OVTerminate.Models;
using OVTerminate.Transactions.Base;

namespace OVTerminate.UserControls
{
    /// <summary>
    /// Interaction logic for AddTransactionUserControl.xaml
    /// </summary>
    public partial class AddTransactionUserControl : UserControl
    {
        public AddTransactionUserControl()
        {
            InitializeComponent();

            TimeControl.Value = DateTime.Now;
            DateControl.SelectedDate = DateTime.Now;

            PointerControl.ItemsSource = x2804556.GetPossiblePointers();
            Pointer2Control.ItemsSource = x2904554.GetPossiblePointers();

            CompanyControl.ItemsSource = StationService.GetCompanys();

            //Select defaults
            PointerControl.SelectedIndex = 0;
            Pointer2Control.SelectedIndex = 0;
            CompanyControl.SelectedIndex = 0;
            StationControl.SelectedIndex = 0;
        }

        private void CompanyControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StationControl.ItemsSource = StationService.GetStationsForCompany(((Company)CompanyControl.SelectedItem).Id);

        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Check for existing transaction IDs
                foreach (var action in App.Transactions)
                {
                    if (action is Transaction)
                    {
                        Transaction trans = action as Transaction;

                        if (trans.TransactionId == int.Parse(TransactionIdControl.Value.ToString()))
                        {
                            MessageBox.Show("Er bestaat al een transactie met dit ID in de wachtrij.");
                            return;
                        }
                    }
                }


                Enums.ActionType actionType = Enums.ActionType.Checkin;
                decimal amount = decimal.Parse(AmountControl.Value.ToString());
                decimal creditAmount = amount;

                if (CheckOutRadioButton.IsChecked.HasValue && CheckOutRadioButton.IsChecked.Value)
                    actionType = Enums.ActionType.Checkout;
                else
                {
                    actionType = Enums.ActionType.Checkin;
                    creditAmount = 0 - amount;
                }

                //Create new action
                x2804556 action1 = new x2804556()
                {
                    Date = DateControl.SelectedDate.Value,
                    Time = (DateTime)TimeControl.Value,
                    Amount = amount,
                    Pointer = (string)PointerControl.SelectedValue,
                    TransactionId = int.Parse(TransactionIdControl.Value.ToString()),
                    Station = (Station)StationControl.SelectedItem,
                    Company = StationService.GetCompany(4),
                    ActionType = actionType

                };

                //Create new action
                x2904554 action2 = new x2904554()
                {
                    Date = DateControl.SelectedDate.Value,
                    Time = (DateTime)TimeControl.Value,
                    Amount = amount,
                    Pointer = (string)Pointer2Control.SelectedValue,
                    TransactionId = int.Parse(TransactionIdControl.Value.ToString()),
                    Station = (Station)StationControl.SelectedItem,
                    Company = StationService.GetCompany(4),
                    ActionType = actionType
                };

                //Create new action
                CreditAction action3 = new CreditAction()
                {
                    Amount = creditAmount,
                    TransactionId = int.Parse(TransactionIdControl.Value.ToString())
                    //Pointer = (string)PointerControl.SelectedValue,
                };

                //Create new action
                CustomAction customAction = new CustomAction();


                //Add actions to list
                bool result = WriteActionService.AddAction(action1);

                if(result)
                    result = WriteActionService.AddAction(action2);

                if (result)
                    result = WriteActionService.AddAction(action3);

                if (result)
                    result = WriteActionService.AddAction(customAction);

                if(result)
                    this.Visibility = System.Windows.Visibility.Hidden;

            }
            catch
            {
                MessageBox.Show("Controleer alle invoer waarden.");
            }
        }
    }
}
