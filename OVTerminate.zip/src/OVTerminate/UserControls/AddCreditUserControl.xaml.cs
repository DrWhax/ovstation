﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OVTerminate.Transactions;
using OVTerminate.Services;
using OVTerminate.Models;
using OVTerminate.Transactions.Base;

namespace OVTerminate.UserControls
{
    /// <summary>
    /// Interaction logic for AddCreditUserControl.xaml
    /// </summary>
    public partial class AddCreditUserControl : UserControl
    {
        public AddCreditUserControl()
        {
            InitializeComponent();

            TimeControl.Value = DateTime.Now;
            DateControl.SelectedDate = DateTime.Now;

            PointerControl.ItemsSource = x0810550.GetPossiblePointers();

            StationControl.ItemsSource = StationService.GetStationsForCredit();

            //Select defaults
            PointerControl.SelectedIndex = 0;
            StationControl.SelectedIndex = 0;

        }

        /// <summary>
        /// Save button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Check for existing transaction IDs
                foreach (var action in App.Transactions)
                {
                    if (action is Transaction)
                    {
                        Transaction trans = action as Transaction;

                        if (trans.TransactionId == int.Parse(TransactionIdControl.Value.ToString()))
                        {
                            MessageBox.Show("Er bestaat al een transactie met dit ID in de wachtrij.");
                            return;
                        }
                    }
                }

                //Create new action
                x0810550 transAction = new x0810550()
                {
                    Date = DateControl.SelectedDate.Value,
                    Time = (DateTime)TimeControl.Value,
                    Amount = decimal.Parse(AmountControl.Value.ToString()),
                    Pointer = (string)PointerControl.SelectedValue,
                    TransactionId = int.Parse(TransactionIdControl.Value.ToString()),
                    Station = (Station)StationControl.SelectedItem,
                    Company = StationService.GetCompany(4)

                };

                //Create new action
                CreditAction creditAction = new CreditAction()
                {
                    Amount = decimal.Parse(AmountControl.Value.ToString()),
                    TransactionId = int.Parse(TransactionIdControl.Value.ToString())
                    //Pointer = (string)PointerControl.SelectedValue,
                };


                bool result = WriteActionService.AddAction(transAction);

                if(result)
                    result = WriteActionService.AddAction(creditAction);

                if(result)
                    this.Visibility = System.Windows.Visibility.Hidden;
            }
            catch
            {
                MessageBox.Show("Controleer alle invoer waarden.");
            }
        }
    }
}
