﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OVTerminate.Models
{
    public class Enums
    {
        public enum ActionType
        {
            Checkin = 1,
            Checkout = 2
        }
    }
}
