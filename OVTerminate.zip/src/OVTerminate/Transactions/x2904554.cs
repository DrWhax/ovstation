﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OVTerminate.Transactions.Base;
using OVTerminate.Models;
using System.Globalization;

namespace OVTerminate.Transactions
{
    /// <summary>
    /// Actual checkin transaction?
    /// </summary>
    public class x2904554 : Transaction
    {
        public Enums.ActionType ActionType { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public x2904554()
        {
            Type = "Checkin / uit";
            Identity = "x2904554";
        }

        /// <summary>
        /// Only these pointers are allowed for this type
        /// </summary>
        /// <returns></returns>
        public static List<string> GetPossiblePointers()
        {
            List<string> list = new List<string>();

            //list.Add("b00");
            //list.Add("b20");
            //list.Add("b40");
            //list.Add("b60");
            //list.Add("b80");
            //list.Add("ba0");
            //list.Add("bc0");
            //list.Add("c00");
            //list.Add("c20");
            //list.Add("c40");
            //list.Add("c60");
            list.Add("c80");
            list.Add("ca0");
            list.Add("cc0");
            list.Add("d00");
            list.Add("d20");
            list.Add("d40");
            list.Add("d60");
            list.Add("d80");
            list.Add("da0");
            list.Add("dc0");
            list.Add("e00");
            list.Add("e20");
            list.Add("e40");

            return list;
        }

        /// <summary>
        /// Description to display
        /// </summary>
        /// <returns></returns>
        public override string GetDescription()
        {
            if (ActionType == Enums.ActionType.Checkin)
                return string.Format("Checkin: {0}", this.Station.Name);
            else if (ActionType == Enums.ActionType.Checkout)
                return string.Format("Checkuit: {0}", this.Station.Name);
            else
                return string.Empty;

        }


        /// <summary>
        /// Binary string to write
        /// </summary>
        /// <returns></returns>
        public override string GetBinaryString()
        {
            string binIdentity = Convert.ToString(Int32.Parse("2904554", NumberStyles.AllowHexSpecifier), 2).PadLeft(28, '0');
            string binDate = this.GetBinaryDate().PadLeft(14, '0');
            string binTime = this.GetBinaryTime().PadLeft(11, '0');
            string binUnknownBits = "000";
            string binAction = GetBinaryAction().PadLeft(4, '0');
            string binUnknownBits_2 = "000000010000";
            string binCompany = this.GetBinaryCompany().PadLeft(4, '0');
            string binUnknownBits_3 = "000000000000";
            string binTransactionId = this.GetBinaryTransactionId().PadLeft(12, '0');
            string binStationId = this.GetBinaryStationId().PadLeft(16, '0');
            string binUnknownBits_4 = Convert.ToString(Int64.Parse("140", NumberStyles.AllowHexSpecifier), 2).PadLeft(12, '0');
            string binUnknownBits_5 = Convert.ToString(Int64.Parse("7760f5c0002", NumberStyles.AllowHexSpecifier), 2).PadLeft(44, '0');
            string binAmount = this.GetBinaryAmount().PadLeft(16, '0');
            string binUnknownBits_6 = "00000001";
            string binUnknownBits_7 = "0".PadLeft(60, '0');


            StringBuilder sb = new StringBuilder();
            sb.Append(binIdentity);
            sb.Append(binDate);
            sb.Append(binTime);
            sb.Append(binUnknownBits);
            sb.Append(binAction);
            sb.Append(binUnknownBits_2);
            sb.Append(binCompany);
            sb.Append(binUnknownBits_3);
            sb.Append(binTransactionId);
            sb.Append(binStationId);
            sb.Append(binUnknownBits_4);
            sb.Append(binUnknownBits_5);
            sb.Append(binAmount);
            sb.Append(binUnknownBits_6);
            sb.Append(binUnknownBits_7);

            return sb.ToString();
        }

        private string GetBinaryAction()
        {
            int actionIndex = 0;
            switch (this.ActionType)
            {
                case Enums.ActionType.Checkin:
                    actionIndex = 1;
                    break;
                case Enums.ActionType.Checkout:
                    actionIndex = 2;
                    break;
                default:
                    break;
            }

            return Convert.ToString(actionIndex, 2);
        }
    }
}
