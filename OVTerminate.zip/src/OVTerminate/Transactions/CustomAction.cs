﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OVTerminate.Transactions.Base;

namespace OVTerminate.Transactions
{
    /// <summary>
    /// Custom write action you can implement yourself
    /// </summary>
    public class CustomAction : IWriteAction
    {
        public string Description { get; set; }

        public string Pointer { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public CustomAction()
        {
            Description = "Custom write action";
        }

        /// <summary>
        /// Write data
        /// </summary>
        /// <param name="data"></param>
        public void WriteData(byte[] data)
        {
            //Create your own write implementation
        }
    }
}
