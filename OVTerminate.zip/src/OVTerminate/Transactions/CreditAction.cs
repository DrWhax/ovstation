﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OVTerminate.Transactions.Base;

namespace OVTerminate.Transactions
{
    /// <summary>
    /// Used to change saldo
    /// </summary>
    public class CreditAction : IWriteAction
    {
        public decimal Amount { get; set; }
        public int TransactionId { get; set; }
        public string Pointer { get; set; }

        /// <summary>
        /// Get description to display
        /// </summary>
        public string Description
        {
            get
            {
                return GetDescription();
            }
        }

        /// <summary>
        /// Get description to display
        /// </summary>
        /// <returns></returns>
        private string GetDescription()
        {
            if (Amount > 0)
                return string.Format("Saldo ophoging: +{0}", this.Amount);
            else
                return string.Format("Saldo verlaging: {0}", this.Amount);

        }

        /// <summary>
        /// Write saldo data
        /// </summary>
        /// <param name="data"></param>
        public void WriteData(byte[] data)
        {
            //Read current Credit
            int startIndex = 0xf90;
            int amount1 = (((data[startIndex + 9] & 1) << 13) | ((data[startIndex + 10] & 0xff) << 5)) | ((data[startIndex + 11] >> 3) & 0x1f);
            
            int startIndex_2 = 0xfa0;
            int amount2 = (((data[startIndex_2 + 9] & 1) << 13) | ((data[startIndex_2 + 10] & 0xff) << 5)) | ((data[startIndex_2 + 11] >> 3) & 0x1f);
            int old_TransactionId_2 = int.Parse(data[startIndex_2 + 7].ToString());
            //var a = data[1];
           

            //Save new credit
            //Saldo 1
            int newAmount_2 = (int)amount2 + (Convert.ToInt32(Amount * 100));
            if (newAmount_2 < 0)
                newAmount_2 = 0;

            int newAmount_1 = amount2;
           
            //Write amount 1 (=OLD AMOUNT?)
            int writeIndex = 0xf90;
            WriteAmount(data, writeIndex, newAmount_1, old_TransactionId_2);

            //Write amount 2 (=NEW AMOUNT?)
            int writeIndex2 = 0xfa0;
            WriteAmount(data, writeIndex2, newAmount_2, TransactionId);

           



        }

        private static void WriteAmount(byte[] data, int pointer, int newAmount, int transactionId)
        {
            string binAmount = Convert.ToString(newAmount, 2).PadLeft(14, '0');
            string str2 = Convert.ToString(data[pointer + 9], 2).PadLeft(8, '0') + Convert.ToString(data[pointer + 10], 2).PadLeft(8, '0') + Convert.ToString(data[pointer + 11], 2).PadLeft(8, '0');
            string str3 = str2.Substring(0, 7) + binAmount + str2.Substring(0x15);
            data[pointer + 9] = Convert.ToByte(str3.Substring(0, 8), 2);
            data[pointer + 10] = Convert.ToByte(str3.Substring(8, 8), 2);
            data[pointer + 11] = Convert.ToByte(str3.Substring(0x10, 8), 2);

            //Write credit ID (pointer to transaction ID)
            data[pointer + 7] = Convert.ToByte(Convert.ToString(transactionId, 2).PadLeft(8, '0'), 2);
        }
    }
}
