﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OVTerminate.Transactions.Base;
using OVTerminate.Models;

namespace OVTerminate.Transactions
{
    /// <summary>
    /// Incheck historie transaction (x2804556)
    /// </summary>
    public class x2804556 : Transaction
    {
        public Enums.ActionType ActionType { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public x2804556()
        {
            Type = "Incheck historie";
            Identity = "x2804556";

        }

        /// <summary>
        /// Only these pointers are allowed for this type
        /// </summary>
        /// <returns></returns>
        public static List<string> GetPossiblePointers()
        {
            List<string> list = new List<string>();

            list.Add("b00");
            list.Add("b20");
            list.Add("b40");
            list.Add("b60");
            list.Add("b80");
            list.Add("ba0");
            list.Add("bc0");
            list.Add("c00");
            list.Add("c20");
            list.Add("c40");
            list.Add("c60");
            //list.Add("c80");
            //list.Add("ca0");
            //list.Add("cc0");
            //list.Add("d00");
            //list.Add("d20");
            //list.Add("d40");
            //list.Add("d60");
            //list.Add("d80");
            //list.Add("da0");
            //list.Add("dc0");
            //list.Add("e00");
            //list.Add("e20");
            //list.Add("e40");

            return list;
        }

        /// <summary>
        /// Get description to display
        /// </summary>
        /// <returns></returns>
        public override string GetDescription()
        {
            if (ActionType == Enums.ActionType.Checkin)
                return string.Format("Checkin historie: {0}", this.Station.Name);
            else if (ActionType == Enums.ActionType.Checkout)
                return string.Format("Checkuit historie: {0}", this.Station.Name);
            else
                return string.Empty;

        }

        /// <summary>
        /// Binary string to write
        /// </summary>
        /// <returns></returns>
        public override string GetBinaryString()
        {
            string binIdentity = "0010100000000100010101010110";
            string binDate = this.GetBinaryDate().PadLeft(14, '0');
            string binTime = this.GetBinaryTime().PadLeft(11, '0');
            string binUnknownBits = "010100101000000000000000000";
            string binAction = GetBinaryAction().PadLeft(4, '0');
            string binUnknownBits_2 = "000000000000";
            string binCompany = this.GetBinaryCompany().PadLeft(4, '0');
            string binUnknownBits_3 = "0000000000000000";
            string binTransactionId = this.GetBinaryTransactionId().PadLeft(8, '0');
            string binStationId = this.GetBinaryStationId().PadLeft(16, '0');
            string binUnknownBits_4 = "0001010000001101000110110010001011001110";
            string binAmount = this.GetBinaryAmount().PadLeft(16, '0');
            string binUnknownBits_5 = "010000000000000000000000000000000000000000000000000000000000";

            StringBuilder sb = new StringBuilder();
            sb.Append(binIdentity);
            sb.Append(binDate);
            sb.Append(binTime);
            sb.Append(binUnknownBits);
            sb.Append(binAction);
            sb.Append(binUnknownBits_2);
            sb.Append(binCompany);
            sb.Append(binUnknownBits_3);
            sb.Append(binTransactionId);
            sb.Append(binStationId);
            sb.Append(binUnknownBits_4);
            sb.Append(binAmount);
            sb.Append(binUnknownBits_5);

            return sb.ToString();
        }

        /// <summary>
        /// Binary string version of action
        /// </summary>
        /// <returns></returns>
        private string GetBinaryAction()
        {
            int actionIndex = 0;
            switch (this.ActionType)
            {
                case Enums.ActionType.Checkin:
                     actionIndex = 1;
                    break;
                case Enums.ActionType.Checkout:
                      actionIndex = 2;
                    break;
                default:
                    break;
            }

            return Convert.ToString(actionIndex, 2);
        }
    }
}
