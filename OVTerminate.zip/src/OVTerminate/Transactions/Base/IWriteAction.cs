﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OVTerminate.Transactions.Base
{
    /// <summary>
    /// Interface for Write Actions
    /// </summary>
    public interface IWriteAction
    {
        /// <summary>
        /// Pointer indicates where to write
        /// </summary>
        string Pointer { get; set; }

        /// <summary>
        /// Get description to display
        /// </summary>
        string Description { get; }

        /// <summary>
        /// Writes the action data
        /// </summary>
        /// <param name="data"></param>
        void WriteData(byte[] data);
    }
}
