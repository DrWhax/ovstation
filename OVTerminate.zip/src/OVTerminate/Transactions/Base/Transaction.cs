﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OVTerminate.Models;
using System.Globalization;

namespace OVTerminate.Transactions.Base
{
    /// <summary>
    /// Transactions (like checkin, add credit)
    /// </summary>
    public abstract class Transaction : IWriteAction
    {
        public string Identity { get; set; }
        public int TransactionId { get; set; }
        public string Type { get; set; }
        public DateTime Date { get; set; }
        public DateTime Time { get; set; }
        public Company Company { get; set; }
        public Station Station { get; set; }
        public decimal Amount { get; set; }
        public string Pointer { get; set; }
        

        public string Description
        {
            get
            {
                return GetDescription();
            }
        }


        protected string GetBinaryDate()
        {
            DateTime startDate = new DateTime(1997, 1, 1);
            TimeSpan delta = this.Date - startDate;
            int days = delta.Days;

            return Convert.ToString(days, 2);
        }

        protected string GetBinaryTime()
        {
            DateTime startDate = new DateTime(1997, 1, 1);
            TimeSpan delta = Time - DateTime.Now.Date;
            int minutes = (delta.Hours * 60) + delta.Minutes;

            return Convert.ToString(minutes, 2);

        }

        protected string GetBinaryCompany()
        {
            return Convert.ToString(Company.Id, 2);
        }

        protected string GetBinaryTransactionId()
        {
            return Convert.ToString(this.TransactionId, 2);
        }

        protected string GetBinaryStationId()
        {
            return Convert.ToString(this.Station.Id, 2);
        }

        protected string GetBinaryAmount()
        {
            int amount = Convert.ToInt32(Amount * 100);
            return Convert.ToString(amount, 2);
        }

        public virtual string GetBinaryString()
        {
            return string.Empty;
        }


        public virtual string GetDescription()
        {
            return string.Empty;
        }


        /// <summary>
        /// Writes data from function GetBinaryString() to the byte array
        /// </summary>
        /// <param name="data"></param>
        public void WriteData(byte[] data)
        {
            string binData = GetBinaryString();

            //Transactions always have this length
            if (binData.Length != 256)
                throw new Exception("Wrong transaction length");

            //Use the pointer as startingpoint
            int startPointer = Int32.Parse(Pointer, NumberStyles.AllowHexSpecifier);

            for (int i = 0; i < 256 / 8; i++)
            {
                int readIndex = 8 * i;
                int writeIndex = startPointer + (1 * i);

                data[writeIndex] = Convert.ToByte(binData.Substring(readIndex, 8), 2);
            }
        }
    }
}
