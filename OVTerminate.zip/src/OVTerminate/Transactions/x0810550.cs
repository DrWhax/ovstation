﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OVTerminate.Transactions.Base;

namespace OVTerminate.Transactions
{
    /// <summary>
    /// Credit transaction
    /// </summary>
    public class x0810550 : Transaction
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public x0810550()
        {
            Type = "Credit";
            Identity = "x0810550";
        }

        /// <summary>
        /// Only these pointers are allowed for this type
        /// </summary>
        /// <returns></returns>
        public static List<string> GetPossiblePointers()
        {
            List<string> list = new List<string>();

            list.Add("e80");
            list.Add("ea0");
            list.Add("ec0");

            return list;
        }

        /// <summary>
        /// Get description to display
        /// </summary>
        /// <returns></returns>
        public override string GetDescription()
        {
            if (Amount > 0)
                return "Credit transactie: +";
            else
                return "Credit transactie: -";

        }

        /// <summary>
        /// Gets the binary string
        /// </summary>
        /// <returns></returns>
        public override string GetBinaryString()
        {
            string binIdentity = "0000100000010000010101010000";
            string binDate = this.GetBinaryDate().PadLeft(14, '0');
            string binTime = this.GetBinaryTime().PadLeft(11, '0');
            string binUnknownBits = "000000000000";
            string binCompany = this.GetBinaryCompany().PadLeft(4, '0');
            string binUnknownBits_2 = "0000000";
            string binTransactionId = this.GetBinaryTransactionId().PadLeft(14, '0');
            string binUnknownBits_3 = "110";
            string binStationId = this.GetBinaryStationId().PadLeft(16, '0');
            string binUnknownBits_4 = "0000011100000101100000010100000";
            string binAmount = this.GetBinaryAmount().PadLeft(14, '0');
            string binUnknownBits_5 = "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";

            StringBuilder sb = new StringBuilder();
            sb.Append(binIdentity);
            sb.Append(binDate);
            sb.Append(binTime);
            sb.Append(binUnknownBits);
            sb.Append(binCompany);
            sb.Append(binUnknownBits_2);
            sb.Append(binTransactionId);
            sb.Append(binUnknownBits_3);
            sb.Append(binStationId);
            sb.Append(binUnknownBits_4);
            sb.Append(binAmount);
            sb.Append(binUnknownBits_5);

            return sb.ToString();
        }

    }
}
