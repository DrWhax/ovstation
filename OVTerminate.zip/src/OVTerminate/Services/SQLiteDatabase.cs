﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Windows.Controls;
using System.Data;
using System.Data.SQLite;

namespace OVTerminate.Services
{
    public class SQLiteDatabase
    {
        // Fields
        private string dbConnection;

        // Methods
        public SQLiteDatabase()
        {
            this.dbConnection = "Data Source=stations.db3";
        }

        public SQLiteDatabase(Dictionary<string, string> connectionOpts)
        {
            string str = "";
            foreach (KeyValuePair<string, string> pair in connectionOpts)
            {
                str = str + string.Format("{0}={1}; ", pair.Key, pair.Value);
            }
            str = str.Trim().Substring(0, str.Length - 1);
            this.dbConnection = str;
        }

        public SQLiteDatabase(string inputFile)
        {
            this.dbConnection = string.Format("Data Source={0}", inputFile);
        }

        public bool ClearDB()
        {
            try
            {
                foreach (DataRow row in this.GetDataTable("select NAME from SQLITE_MASTER where type='table' order by NAME;").Rows)
                {
                    this.ClearTable(row["NAME"].ToString());
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool ClearTable(string table)
        {
            try
            {
                this.ExecuteNonQuery(string.Format("delete from {0};", table));
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool Delete(string tableName, string where)
        {
            bool flag = true;
            try
            {
                this.ExecuteNonQuery(string.Format("delete from {0} where {1};", tableName, where));
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
                flag = false;
            }
            return flag;
        }

        public int ExecuteNonQuery(string sql)
        {
            SQLiteConnection connection = new SQLiteConnection(this.dbConnection);
            connection.Open();
            SQLiteCommand command = new SQLiteCommand(connection);
            command.CommandText = sql;
            int num = command.ExecuteNonQuery();
            connection.Close();
            return num;
        }

        public string ExecuteScalar(string sql)
        {
            SQLiteConnection connection = new SQLiteConnection(this.dbConnection);
            connection.Open();
            SQLiteCommand command = new SQLiteCommand(connection);
            command.CommandText = sql;
            object obj2 = command.ExecuteScalar();
            connection.Close();
            if (obj2 != null)
            {
                return obj2.ToString();
            }
            return "";
        }

        public DataTable GetDataTable(string sql)
        {
            DataTable table = new DataTable();
            try
            {
                SQLiteConnection connection = new SQLiteConnection(this.dbConnection);
                connection.Open();
                SQLiteCommand command = new SQLiteCommand(connection);
                command.CommandText = sql;
                SQLiteDataReader reader = command.ExecuteReader();
                table.Load(reader);
                reader.Close();
                connection.Close();
            }
            catch (Exception exception)
            {
                throw new Exception(exception.Message);
            }
            return table;
        }

        public bool Insert(string tableName, Dictionary<string, string> data)
        {
            string str = "";
            string str2 = "";
            bool flag = true;
            foreach (KeyValuePair<string, string> pair in data)
            {
                str = str + string.Format(" {0},", pair.Key.ToString());
                str2 = str2 + string.Format(" '{0}',", pair.Value);
            }
            str = str.Substring(0, str.Length - 1);
            str2 = str2.Substring(0, str2.Length - 1);
            try
            {
                this.ExecuteNonQuery(string.Format("insert into {0}({1}) values({2});", tableName, str, str2));
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
                flag = false;
            }
            return flag;
        }

        public bool Update(string tableName, Dictionary<string, string> data, string where)
        {
            string str = "";
            bool flag = true;
            if (data.Count >= 1)
            {
                foreach (KeyValuePair<string, string> pair in data)
                {
                    str = str + string.Format(" {0} = '{1}',", pair.Key.ToString(), pair.Value.ToString());
                }
                str = str.Substring(0, str.Length - 1);
            }
            try
            {
                this.ExecuteNonQuery(string.Format("update {0} set {1} where {2};", tableName, str, where));
            }
            catch
            {
                flag = false;
            }
            return flag;
        }
    }
}
