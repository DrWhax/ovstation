﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OVTerminate.Transactions.Base;
using System.Windows;

namespace OVTerminate.Services
{
    public static class WriteActionService
    {
        public static bool AddAction(IWriteAction action)
        {
            if (!string.IsNullOrEmpty(action.Pointer))
            {
                int count = App.Transactions.Where(x => x.Pointer == action.Pointer).Count();

                if (count > 0)
                {
                    MessageBox.Show("Er bestaat al een transactie met deze pointer in de wachtrij.");
                    return false;
                }

            }

            App.Transactions.Add(action);

            return true;
        }

        public static void WriteAllData()
        {
            if (App.DumpData != null)
            {
                foreach (var action in App.Transactions)
                {
                    action.WriteData(App.DumpData);
                }

                App.Transactions.Clear();
            }
        }

        
    }
}
