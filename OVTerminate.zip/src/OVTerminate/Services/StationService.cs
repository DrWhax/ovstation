﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OVTerminate.Models;
using System.Data;

namespace OVTerminate.Services
{
    public static class StationService
    {
        public static List<Company> GetCompanys()
        {
            List<Company> list = new List<Company>();

            list.Add(new Company() { Id = 4, Name = "NS" });
            //list.Add(new Company() { Id = 1, Name = "Connexxion" });
            list.Add(new Company() { Id = 2, Name = "GVB" });
            //list.Add(new Company() { Id = 3, Name = "HTM" });
            list.Add(new Company() { Id = 5, Name = "RET" });
            list.Add(new Company() { Id = 7, Name = "Veolia" });
            //list.Add(new Company() { Id = 8, Name = "Arriva" });
            //list.Add(new Company() { Id = 9, Name = "Syntus " });
            //list.Add(new Company() { Id = 12, Name = "DUO" });

            return list;
        }

        public static Company GetCompany(int p)
        {
            return (from x in GetCompanys() where x.Id == p select x).FirstOrDefault();
        }

        public static List<Station> GetStationsForCompany(int companyId)
        {
            List<Station> list = new List<Station>();

            SQLiteDatabase database = new SQLiteDatabase();
            string sql = string.Format("select TITLE, ovcid from stations where company = '{0}' order by 1 asc;", companyId);

            if (companyId == 4)
                sql = string.Format("select TITLE, ovcid from stations where ovcid between 1 and 752 and company = '{0}' order by 1 asc;", companyId);

            foreach (DataRow row in database.GetDataTable(sql).Rows)
            {
                Station station = new Station()
                {
                    Id = int.Parse(row["ovcid"].ToString()),
                    Name = row["TITLE"].ToString()
                };

                list.Add(station);
            }

            return list;
        }

        public static List<Station> GetStationsForCredit()
        {
            List<Station> list = new List<Station>();

            SQLiteDatabase database = new SQLiteDatabase();
            string sql = string.Format("select TITLE, ovcid from stations where company = '4' AND ovcid > 752 order by 1 asc;");
          
            foreach (DataRow row in database.GetDataTable(sql).Rows)
            {
                Station station = new Station()
                {
                    Id = int.Parse(row["ovcid"].ToString()),
                    Name = row["TITLE"].ToString()
                };

                list.Add(station);
            }

            return list;
        }

        
    }
}
